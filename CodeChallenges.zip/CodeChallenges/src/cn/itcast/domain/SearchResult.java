package cn.itcast.domain;

public class SearchResult {

    private String sulr;
    private String stitle;

    public String getSulr() {
        return sulr;
    }

    public void setSulr(String sulr) {
        this.sulr = sulr;
    }

    public String getStitle() {
        return stitle;
    }

    public void setStitle(String stitle) {
        this.stitle = stitle;
    }

    @Override
    public String toString() {
        return "SearchResult{" +
                "sulr='" + sulr + '\'' +
                ", stitle='" + stitle + '\'' +
                '}';
    }
}
