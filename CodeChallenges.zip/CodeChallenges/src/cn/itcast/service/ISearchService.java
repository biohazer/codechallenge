package cn.itcast.service;

public interface ISearchService {

    String searchRank();
}
