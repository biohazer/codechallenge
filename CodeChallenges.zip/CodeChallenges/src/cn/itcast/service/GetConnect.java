package cn.itcast.service;

import java.io.*;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;


public class GetConnect {

    public static String getPage(String page) {

        try {

            URL url = new URL(page);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            //setup google browser agent
            con.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0;Windows NT; DigExt)");

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                b.append(line);
                b.append("\r\n");
            }
            //return all html code
            return b.toString();
        } catch (FileNotFoundException ex) {
            System.out.println("NOT FOUND:" + page);
            return null;
        } catch (ConnectException ex) {
            System.out.println("Timeout:" + page);
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
