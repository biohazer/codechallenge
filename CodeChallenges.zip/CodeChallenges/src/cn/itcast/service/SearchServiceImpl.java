package cn.itcast.service;

import cn.itcast.domain.SearchResult;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class SearchServiceImpl implements ISearchService {

    private List<Integer> record = new ArrayList<Integer>();
    private List<SearchResult> searchResults = new ArrayList<>();

    String url = "https://www.google.com.au/search?as_q=online+title+search&num=100";
    //get all the context from html searching page
    String content = GetConnect.getPage(url);
    //pattern all html code to each searching list
    Matcher matcher = Pattern.compile("(<div class=\"ezO2md\".*?</div>)").matcher(content);

    @Override
    public String searchRank() {
            //searching list from number 1
            int i = 1;

            while(matcher.find()) {
                String mx = matcher.group();
                //matching searching list contain url www.infotrack.com.au
                Pattern p =Pattern.compile("(www.infotrack.com.au)");
                Matcher m = p.matcher(mx);

                if(m.find()){
                    //get the www.infotrack.com.au rank number and store in a List
                    String grouped = m.group();
                    record.add(i);
                    System.out.println("this info find :"+grouped);
                }
                i++;

            }
            System.out.println("infotrack count in :"+record);

            return record.toString();
    }

}
